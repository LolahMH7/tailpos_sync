# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from frappe import _


def get_data():
	return [
		{
			"module_name": "TailPOS Sync",
			"color": "#3498db",
			"icon": "octicon octicon-credit-card",
			"type": "module",
			"label": _("TailPOS Sync")
		}
	]
