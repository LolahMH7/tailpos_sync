

// cur_frm.cscript.before_submit = function () {
//     frappe.call({
//         method: "tailpos_sync.doc_events.sales_invoice.before_submit",
//         args: {}
//
//     })
// }

