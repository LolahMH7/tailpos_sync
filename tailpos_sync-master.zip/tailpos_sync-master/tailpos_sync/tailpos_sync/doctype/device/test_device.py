# -*- coding: utf-8 -*-
# Copyright (c) 2018, Bai Web and Mobile Lab and Contributors
# See license.txt
from __future__ import unicode_literals

import frappe
import unittest

class TestDevice(unittest.TestCase):
	pass
