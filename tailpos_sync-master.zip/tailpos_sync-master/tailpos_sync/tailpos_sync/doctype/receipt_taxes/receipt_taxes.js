// Copyright (c) 2020, Bai Web and Mobile Lab and contributors
// For license information, please see license.txt

frappe.ui.form.on('Receipt Taxes', {
	// refresh: function(frm) {

	// }
});
