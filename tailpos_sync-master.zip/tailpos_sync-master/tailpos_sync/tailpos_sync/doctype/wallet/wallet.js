// Copyright (c) 2019, Bai Web and Mobile Lab and contributors
// For license information, please see license.txt

frappe.ui.form.on('Wallet', {
	// refresh: function(frm) {

	// }
});
