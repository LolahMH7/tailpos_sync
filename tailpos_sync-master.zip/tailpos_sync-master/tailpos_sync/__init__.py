# -*- coding: utf-8 -*-
from __future__ import unicode_literals

__version__ = '1.7.4'
